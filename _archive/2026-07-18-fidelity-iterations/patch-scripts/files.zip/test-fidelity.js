// test-fidelity.js
// Local sanity check — run BEFORE wiring anything into server.js.
//
// Usage:
//   ANTHROPIC_API_KEY=sk-ant-... node test-fidelity.js
//
// Paste in a real manuscript excerpt and its FluidScriptr-generated
// screenplay conversion below, then check whether the omission
// classifications and dialogue categories look right to you. Run it 2-3
// times on the same pair — the extraction should be roughly stable even
// if exact wording varies. If the omission classifications or dialogue
// categories swing wildly between runs, tighten the prompt (e.g. add a
// worked example) before moving to scoring.js.

const { buildStructuralAndOmissionPrompt, buildDialoguePrompt } = require("./prompts");
const { computeFidelityScores } = require("./scoring");

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";

// Pulls the JSON object out of a response even if Claude added a stray
// sentence of commentary before or after it (which it sometimes does
// despite being told not to). Finds the first "{" and the matching last
// "}" and parses just that slice.
function extractJSON(text) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end < start) {
    throw new Error("No JSON object found in response:\n" + text);
  }
  const slice = text.slice(start, end + 1);
  return JSON.parse(slice);
}

async function callClaude(system, user) {
  const res = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 8000,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });
  const data = await res.json();

  if (data.error) {
    throw new Error("Anthropic API error: " + JSON.stringify(data.error));
  }

  if (data.stop_reason === "max_tokens") {
    throw new Error(
      "Response got cut off before finishing (hit the max_tokens limit). " +
      "Try a shorter manuscript/screenplay excerpt for this test, or raise " +
      "max_tokens further in this file."
    );
  }

  const text = data.content?.map((b) => b.text || "").join("") || "";
  return extractJSON(text);
}

async function main() {
  const manuscriptText = `PASTE A REAL MANUSCRIPT EXCERPT HERE (a few chapters is plenty for a first test)`;
  const screenplayText = `PASTE ITS FLUIDSCRIPTR SCREENPLAY CONVERSION HERE`;

  // Match whatever you actually picked in FluidScriptr's conversion settings —
  // this changes how omissions and mappings get judged. See prompts.js for
  // the exact option strings recognized (FORMAT_GUIDANCE / APPROACH_GUIDANCE /
  // TONE_GUIDANCE / DIALOGUE_STYLE_GUIDANCE).
  const conversionSettings = {
    targetFormat: "Short Film",       // "Feature Film" | "Limited Series" | "TV Pilot" | "Short Film"
    adaptationApproach: "Compress",   // "Compress" | "Select Best" | "Faithful"
    tone: "Faithful to source",       // "Faithful to source" | "Cinematic / visual-first" | "Compressed / tight pacing" | "Expanded with subtext"
    dialogueStyle: "Naturalistic",    // "Naturalistic" | "Stylized / Literary" | "Minimal — let visuals carry" | "Heavy subtext"
  };

  console.log("Running structural + omission extraction...");
  const sp = buildStructuralAndOmissionPrompt(manuscriptText, screenplayText, conversionSettings);
  const structuralOmissionResult = await callClaude(sp.system, sp.user);
  console.log(JSON.stringify(structuralOmissionResult, null, 2));

  console.log("\nRunning dialogue extraction...");
  const dp = buildDialoguePrompt(manuscriptText, screenplayText, conversionSettings);
  const dialogueResult = await callClaude(dp.system, dp.user);
  console.log(JSON.stringify(dialogueResult, null, 2));

  console.log("\nComputed scores:");
  const scores = computeFidelityScores(structuralOmissionResult, dialogueResult);
  console.log(scores);
}

main().catch(console.error);
